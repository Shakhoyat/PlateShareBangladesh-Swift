//
//  String+Extensions.swift
//  PlateShareBD
//
//  Created by PlateShare Team.
//

import Foundation

extension String {
    /// Format a raw phone number to Bangladeshi E.164 format
    var toBangladeshiE164: String {
        let digits = self.filter { $0.isNumber }
        if digits.hasPrefix("880") { return "+\(digits)" }
        if digits.hasPrefix("0") { return "+88\(digits)" }
        return "+880\(digits)"
    }

    /// Validate Bangladeshi phone number format
    var isValidBangladeshiPhone: Bool {
        let digits = self.filter { $0.isNumber }
        // Bangladeshi numbers: 11 digits starting with 01
        if digits.hasPrefix("01") && digits.count == 11 { return true }
        // With country code: 13 digits starting with 880
        if digits.hasPrefix("880") && digits.count == 13 { return true }
        return false
    }

    /// Truncate a string to a max length with ellipsis
    func truncated(to maxLength: Int) -> String {
        if self.count <= maxLength { return self }
        return String(self.prefix(maxLength)) + "..."
    }
}

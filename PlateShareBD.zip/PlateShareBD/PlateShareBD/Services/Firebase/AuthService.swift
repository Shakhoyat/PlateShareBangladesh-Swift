//
//  AuthService.swift
//  PlateShareBD
//
//  Created by PlateShare Team.
//

import Foundation
import FirebaseAuth
import FirebaseFirestore

// Typed error enum — never expose raw Firebase errors to ViewModels
enum AuthError: LocalizedError {
    case invalidPhoneNumber
    case invalidOTP
    case otpExpired
    case tooManyRequests
    case networkError
    case userNotFound
    case profileSetupRequired
    case unknown(String)

    var errorDescription: String? {
        switch self {
        case .invalidPhoneNumber: return "Please enter a valid Bangladeshi phone number."
        case .invalidOTP: return "The verification code is incorrect."
        case .otpExpired: return "Code expired. Please request a new one."
        case .tooManyRequests: return "Too many attempts. Please wait before trying again."
        case .networkError: return "No internet connection. Please check your network."
        case .userNotFound: return "Account not found."
        case .profileSetupRequired: return "Please complete your profile."
        case .unknown(let msg): return msg
        }
    }
}

@MainActor
final class AuthService {
    static let shared = AuthService()
    private init() {}

    private let db = Firestore.firestore()
    private var verificationID: String?

    // STEP 1: Send OTP to phone number
    // phoneNumber MUST be in E.164 format: "+8801712345678"
    func sendOTP(to phoneNumber: String) async throws {
        // Format check
        guard phoneNumber.hasPrefix("+880"), phoneNumber.count == 14 else {
            throw AuthError.invalidPhoneNumber
        }

        do {
            let verificationID = try await PhoneAuthProvider.provider()
                .verifyPhoneNumber(phoneNumber, uiDelegate: nil)
            self.verificationID = verificationID
        } catch let error as NSError {
            throw mapFirebaseAuthError(error)
        }
    }

    // STEP 2: Verify OTP code entered by user
    func verifyOTP(_ code: String) async throws -> AuthDataResult {
        guard let verificationID = verificationID else {
            throw AuthError.invalidOTP
        }

        let credential = PhoneAuthProvider.provider().credential(
            withVerificationID: verificationID,
            verificationCode: code
        )

        do {
            return try await Auth.auth().signIn(with: credential)
        } catch let error as NSError {
            throw mapFirebaseAuthError(error)
        }
    }

    // STEP 3: Check if user profile exists in Firestore
    func checkUserProfile(uid: String) async throws -> Bool {
        let doc = try await db.collection(FirestoreKeys.Collections.users).document(uid).getDocument()
        return doc.exists
    }

    // STEP 4: Create user profile in Firestore
    func createUserProfile(_ user: PSUser) async throws {
        let data = try Firestore.Encoder().encode(user)
        try await db.collection(FirestoreKeys.Collections.users).document(user.id).setData(data)
    }

    // Fetch user profile
    func fetchUserProfile(uid: String) async throws -> PSUser {
        let doc = try await db.collection(FirestoreKeys.Collections.users).document(uid).getDocument()
        guard let user = try? doc.data(as: PSUser.self) else {
            throw AuthError.userNotFound
        }
        return user
    }

    // Sign out
    func signOut() throws {
        try Auth.auth().signOut()
    }

    // Current user
    var currentUser: FirebaseAuth.User? {
        Auth.auth().currentUser
    }

    // Map Firebase error codes to our typed errors
    private func mapFirebaseAuthError(_ error: NSError) -> AuthError {
        print("🔴 RAW FIREBASE AUTH ERROR: \(error.localizedDescription)")
        print("🔴 DOMAIN: \(error.domain) CODE: \(error.code)")
        print("🔴 USER INFO: \(error.userInfo)")
        
        // Handle specific hidden backend errors like Billing
        if let underlyingError = error.userInfo[NSUnderlyingErrorKey] as? NSError,
           let deserializedResponse = underlyingError.userInfo["FIRAuthErrorUserInfoDeserializedResponseKey"] as? [String: Any],
           let message = deserializedResponse["message"] as? String,
           message == "BILLING_NOT_ENABLED" {
            return .unknown("Firebase Error: Your Firebase project requires the Blaze (pay-as-you-go) billing plan to use Phone Authentication. Please upgrade in the Firebase Console.")
        }
        
        guard let code = AuthErrorCode(rawValue: error.code) else {
            return .unknown(error.localizedDescription)
        }
        
        switch code {
        case .invalidPhoneNumber: return .invalidPhoneNumber
        case .invalidVerificationCode: return .invalidOTP
        case .sessionExpired: return .otpExpired
        case .tooManyRequests: return .tooManyRequests
        case .networkError: return .networkError
        case .internalError: 
            return .unknown("Internal Firebase Error. Check Xcode console for details: \(error.localizedDescription)")
        default: return .unknown("Firebase Error: \(error.localizedDescription)")
        }
    }
}

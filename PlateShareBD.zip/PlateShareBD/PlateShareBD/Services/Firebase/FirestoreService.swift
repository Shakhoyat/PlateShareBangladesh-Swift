//
//  FirestoreService.swift
//  PlateShareBD
//
//  Created by PlateShare Team.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth
import Combine

enum AppError: LocalizedError {
    case notAuthenticated
    case permissionDenied
    case documentNotFound
    case encodingError
    case networkError
    case unknown(String)

    var errorDescription: String? {
        switch self {
        case .notAuthenticated: return "You must be logged in."
        case .permissionDenied: return "You don't have permission for this action."
        case .documentNotFound: return "The requested content was not found."
        case .encodingError: return "Data processing error. Please try again."
        case .networkError: return "Network error. Check your internet connection."
        case .unknown(let msg): return msg
        }
    }
}

final class FirestoreService {
    static let shared = FirestoreService()
    private init() {}

    private let db = Firestore.firestore()

    // ─── LISTINGS ────────────────────────────────────────────

    // Create a new listing
    func createListing(_ listing: FoodListing) async throws {
        guard Auth.auth().currentUser != nil else { throw AppError.notAuthenticated }

        do {
            let data = try Firestore.Encoder().encode(listing)
            try await db.collection(FirestoreKeys.Collections.listings).document(listing.id).setData(data)
        } catch {
            throw AppError.encodingError
        }
    }

    // Fetch paginated listings for the feed
    func fetchListings(
        limit: Int = 20,
        after lastDocument: DocumentSnapshot? = nil
    ) async throws -> ([FoodListing], DocumentSnapshot?) {
        var query: Query = db.collection(FirestoreKeys.Collections.listings)
            .whereField(FirestoreKeys.ListingFields.isAvailable, isEqualTo: true)
            .whereField(FirestoreKeys.ListingFields.expiresAt, isGreaterThan: Timestamp(date: Date()))
            .order(by: FirestoreKeys.ListingFields.expiresAt)
            .order(by: FirestoreKeys.ListingFields.createdAt, descending: true)
            .limit(to: limit)

        if let lastDoc = lastDocument {
            query = query.start(afterDocument: lastDoc)
        }

        let snapshot = try await query.getDocuments()
        let listings = snapshot.documents.compactMap { try? $0.data(as: FoodListing.self) }
        return (listings, snapshot.documents.last)
    }

    // Real-time listener for feed (using Combine)
    func listingsPublisher() -> AnyPublisher<[FoodListing], Never> {
        let subject = PassthroughSubject<[FoodListing], Never>()

        db.collection(FirestoreKeys.Collections.listings)
            .whereField(FirestoreKeys.ListingFields.isAvailable, isEqualTo: true)
            .whereField(FirestoreKeys.ListingFields.expiresAt, isGreaterThan: Timestamp(date: Date()))
            .order(by: FirestoreKeys.ListingFields.expiresAt)
            .limit(to: 50)
            .addSnapshotListener { snapshot, error in
                guard let documents = snapshot?.documents else { return }
                let listings = documents.compactMap { try? $0.data(as: FoodListing.self) }
                subject.send(listings)
            }

        return subject.eraseToAnyPublisher()
    }

    // Mark listing as taken
    func markListingTaken(listingId: String) async throws {
        try await db.collection(FirestoreKeys.Collections.listings).document(listingId)
            .updateData([FirestoreKeys.ListingFields.isAvailable: false])
    }

    // Fetch listings for a specific donor
    func fetchUserListings(donorId: String) async throws -> [FoodListing] {
        let snapshot = try await db.collection(FirestoreKeys.Collections.listings)
            .whereField(FirestoreKeys.ListingFields.donorId, isEqualTo: donorId)
            .order(by: FirestoreKeys.ListingFields.createdAt, descending: true)
            .getDocuments()
        return snapshot.documents.compactMap { try? $0.data(as: FoodListing.self) }
    }

    // Delete a listing
    func deleteListing(listingId: String) async throws {
        try await db.collection(FirestoreKeys.Collections.listings).document(listingId).delete()
    }

    // ─── MESSAGING ────────────────────────────────────────────

    // Get or create a conversation
    func getOrCreateConversation(
        listingId: String,
        donorId: String,
        recipientId: String
    ) async throws -> PSConversation {
        // Check if conversation already exists
        let existing = try await db.collection(FirestoreKeys.Collections.conversations)
            .whereField(FirestoreKeys.ConversationFields.listingId, isEqualTo: listingId)
            .whereField(FirestoreKeys.ConversationFields.participantIds, arrayContains: recipientId)
            .getDocuments()

        if let doc = existing.documents.first,
           let conversation = try? doc.data(as: PSConversation.self) {
            return conversation
        }

        // Create new conversation
        let conversationId = db.collection(FirestoreKeys.Collections.conversations).document().documentID
        let conversation = PSConversation(
            id: conversationId,
            listingId: listingId,
            participantIds: [donorId, recipientId],
            lastMessage: nil,
            lastMessageAt: nil,
            unreadCount: 0
        )

        let data = try Firestore.Encoder().encode(conversation)
        try await db.collection(FirestoreKeys.Collections.conversations).document(conversationId).setData(data)
        return conversation
    }

    // Send a message
    func sendMessage(
        conversationId: String,
        text: String
    ) async throws {
        guard let currentUID = Auth.auth().currentUser?.uid else {
            throw AppError.notAuthenticated
        }

        let messageId = db.collection(FirestoreKeys.Collections.conversations)
            .document(conversationId)
            .collection(FirestoreKeys.Collections.messages)
            .document().documentID

        let message = PSMessage(
            id: messageId,
            senderId: currentUID,
            conversationId: conversationId,
            text: text,
            audioURL: nil,
            isRead: false,
            createdAt: Date()
        )

        let messageData = try Firestore.Encoder().encode(message)

        // Batch write: add message + update conversation's lastMessage
        let batch = db.batch()
        let messageRef = db.collection(FirestoreKeys.Collections.conversations)
            .document(conversationId)
            .collection(FirestoreKeys.Collections.messages)
            .document(messageId)
        batch.setData(messageData, forDocument: messageRef)

        let conversationRef = db.collection(FirestoreKeys.Collections.conversations).document(conversationId)
        batch.updateData([
            FirestoreKeys.ConversationFields.lastMessage: text,
            FirestoreKeys.ConversationFields.lastMessageAt: Timestamp(date: Date()),
            FirestoreKeys.ConversationFields.unreadCount: FieldValue.increment(Int64(1))
        ], forDocument: conversationRef)

        try await batch.commit()
    }

    // Real-time messages listener
    func messagesPublisher(conversationId: String) -> AnyPublisher<[PSMessage], Never> {
        let subject = PassthroughSubject<[PSMessage], Never>()

        db.collection(FirestoreKeys.Collections.conversations)
            .document(conversationId)
            .collection(FirestoreKeys.Collections.messages)
            .order(by: FirestoreKeys.MessageFields.createdAt)
            .addSnapshotListener { snapshot, _ in
                guard let documents = snapshot?.documents else { return }
                let messages = documents.compactMap { try? $0.data(as: PSMessage.self) }
                subject.send(messages)
            }

        return subject.eraseToAnyPublisher()
    }

    // Fetch user conversations
    func fetchConversations(userId: String) async throws -> [PSConversation] {
        let snapshot = try await db.collection(FirestoreKeys.Collections.conversations)
            .whereField(FirestoreKeys.ConversationFields.participantIds, arrayContains: userId)
            .order(by: FirestoreKeys.ConversationFields.lastMessageAt, descending: true)
            .getDocuments()
        return snapshot.documents.compactMap { try? $0.data(as: PSConversation.self) }
    }

    // ─── USERS ────────────────────────────────────────────────

    func fetchUser(uid: String) async throws -> PSUser {
        let doc = try await db.collection(FirestoreKeys.Collections.users).document(uid).getDocument()
        guard let user = try? doc.data(as: PSUser.self) else {
            throw AppError.documentNotFound
        }
        return user
    }

    func updateUser(uid: String, data: [String: Any]) async throws {
        try await db.collection(FirestoreKeys.Collections.users).document(uid).updateData(data)
    }
}
